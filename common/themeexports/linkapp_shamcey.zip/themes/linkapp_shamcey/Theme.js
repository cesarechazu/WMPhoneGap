{
	"wm.AppRoot": {
	}, 
	"wm.AccordionLayers": {
		"captionHeight": "40", 
		"margin": undefined, 
		"arrowsOnLeft": false
	}, 
	"wm.TabLayers": {
		"headerHeight": "28px", 
		"mobileHeaderHeight": "20 px", 
		"headerWidth": "22 px", 
		"border": 1, 
		"borderColor": "#0866c6", 
		"clientBorder": undefined, 
		"clientBorderColor": "#ffffff"
	}, 
	"wm.FancyPanel": {
		"borderColor": "#0866c6", 
		"innerBorder": "1", 
		"labelHeight": "40"
	}, 
	"wm.Button": {
		"border": 0
	}, 
	"wm.ToggleButton": {
		"border": 0
	}, 
	"wm.PopupMenuButton": {
		"border": 0
	}, 
	"wm.ToggleButtonPanel": {
	}, 
	"wm.Text": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.LargeTextArea": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.Number": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.Currency": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.SelectMenu": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.Lookup": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.FilteringLookup": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.Date": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.Time": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.DateTime": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.Checkbox": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.RadioButton": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.RichText": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.CheckboxSet": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.RadioSet": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.ListSet": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.Slider": {
		"desktopHeight": "34px", 
		"captionPosition": "left", 
		"captionAlign": "right", 
		"mobileHeight": "32px"
	}, 
	"wm.DojoGrid": {
	}, 
	"wm.List": {
	}
}