{
	"wm.AppRoot": {
	}, 
	"wm.TabLayers": {
		"border": 1, 
		"borderColor": "#dedede", 
		"headerHeight": "32px", 
		"clientBorder": "1", 
		"clientBorderColor": "#666666"
	}, 
	"wm.AccordionLayers": {
		"border": 1, 
		"borderColor": "#666666"
	}, 
	"wm.FancyPanel": {
		"borderColor": "#666666", 
		"innerBorder": "1", 
		"labelHeight": "32"
	}, 
	"wm.Button": {
	}, 
	"wm.ToggleButton": {
	}, 
	"wm.PopupMenuButton": {
	}, 
	"wm.ToggleButtonPanel": {
	}, 
	"wm.Text": {
		"editorBorder": true
	}, 
	"wm.LargeTextArea": {
		"editorBorder": true
	}, 
	"wm.Number": {
		"editorBorder": true
	}, 
	"wm.Currency": {
		"editorBorder": true
	}, 
	"wm.SelectMenu": {
		"editorBorder": true
	}, 
	"wm.Lookup": {
		"editorBorder": true
	}, 
	"wm.FilteringLookup": {
		"editorBorder": true
	}, 
	"wm.Date": {
		"editorBorder": true
	}, 
	"wm.Time": {
		"editorBorder": true
	}, 
	"wm.DateTime": {
		"editorBorder": true
	}, 
	"wm.Checkbox": {
		"editorBorder": true
	}, 
	"wm.RadioButton": {
		"editorBorder": true
	}, 
	"wm.RichText": {
		"editorBorder": true
	}, 
	"wm.CheckboxSet": {
		"editorBorder": true
	}, 
	"wm.RadioSet": {
		"editorBorder": true
	}, 
	"wm.ListSet": {
		"editorBorder": true
	}, 
	"wm.Slider": {
		"editorBorder": true
	}, 
	"wm.DojoGrid": {
		"desktopHeight": "200px", 
		"padding": "0"
	}, 
	"wm.List": {
		"desktopHeight": "200px", 
		"padding": "0"
	}, 
	"wm.dijit.ProgressBar": {
		"padding": "6"
	}, 
	"wm.Bevel": {
		"bevelSize": "3"
	}, 
	"wm.Splitter": {
		"bevelSize": "3"
	}, 
	"wm.dijit.Calendar": {
		"padding": "6", 
		"desktopHeight": "180px"
	}, 
	"wm.Dialog": {
		"footerBorder": "1,0,0,0"
	}, 
	"wm.PageDialog": {
		"footerBorder": "1,0,0,0"
	}, 
	"wm.GenericDialog": {
		"footerBorder": "1,0,0,0"
	}, 
	"wm.DesignableDialog": {
		"footerBorder": "1,0,0,0"
	}, 
	"wm.DojoMenu": {
	}, 
	"wm.Toast": {
	}, 
	"wm.ButtonBarPanel": {
	}
}